"""MFCC mono, 22050 Hz, float32; configuración exportada con librosa."""
import numpy as np
from scipy.fft import rfft, dct

class MFCCLigero:
    def __init__(self, path):
        with np.load(path, allow_pickle=False) as f:
            if str(f['format']) != 'PFI-MFCC-v1':
                raise ValueError('Configuración MFCC incompatible')
            self.window = f['window'].copy()
            self.mel = f['mel'].copy()
        if self.window.shape != (2048,) or self.mel.shape != (128, 1025):
            raise ValueError('Dimensiones MFCC incompatibles')

    def __call__(self, y):
        y = np.asarray(y)
        if y.dtype != np.float32 or y.shape != (110250,) or not np.isfinite(y).all():
            raise ValueError('Se requiere mono float32, 5 s a 22050 Hz')
        padded = np.pad(y, (1024, 1024), mode='constant')
        frames = np.lib.stride_tricks.sliding_window_view(padded, 2048)[::512].T
        # Bloques pequeños limitan los temporales de FFT, preservando float64
        # en ventana * audio y el redondeo complex64 de librosa.stft.
        power = np.empty((1025, frames.shape[1]), dtype=np.float32, order='F')
        for start in range(0, frames.shape[1], 16):
            end = min(start + 16, frames.shape[1])
            z = rfft(self.window[:, None] * frames[:, start:end], axis=0,
                     workers=1).astype(np.complex64)
            power[:, start:end] = np.abs(z) ** 2
        mel_power = np.einsum('...ft,mf->...mt', power, self.mel, optimize=True)
        db = 10.0 * np.log10(np.maximum(1e-10, mel_power))
        db -= 10.0 * np.log10(np.maximum(1e-10, 1.0))
        db = np.maximum(db, db.max() - 80.0)
        return dct(db, type=2, axis=0, norm='ortho', workers=1)[:40][None, ...]
