#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for vuelta in 1 2; do
  if [ "$vuelta" -eq 1 ]; then motores=(librosa ligero); else motores=(ligero librosa); fi
  for motor in "${motores[@]}"; do
    LC_ALL=C NUMBA_DEBUG_CACHE=1 /usr/bin/time -v \
      -o "memoria_${motor}_${vuelta}.txt" \
      python3 -u etapa4.py medir --motor "$motor" \
      2>&1 | tee "salida_${motor}_${vuelta}.txt"
  done
done
