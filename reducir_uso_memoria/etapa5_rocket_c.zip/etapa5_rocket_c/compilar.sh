#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v cc >/dev/null 2>&1; then
  echo 'Falta compilador C (cc). En Raspberry Pi OS: sudo apt install build-essential' >&2
  exit 1
fi
cc -O3 -std=c11 -fPIC -shared -fno-fast-math -ffp-contract=off \
  rocket_native.c -o librocket_native.so
printf '%s\n' 'COMPILACIÓN C: OK'
