"""Etapa 5: preparar referencias, validar y medir MFCC en procesos separados."""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'NUMBA_NUM_THREADS'):
    os.environ[key] = '1'
os.environ.setdefault('NUMBA_CACHE_DIR', '/tmp/numba_cache')
import time
START = time.perf_counter()
import argparse
from pathlib import Path
import hashlib
import json
import sys
import modelo_npz_base as base


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()


def audio(path):
    import numpy as np
    import soundfile as sf
    y, sr = sf.read(path, dtype='float32', always_2d=True)
    if sr != 22050 or y.shape != (110250, 1) or not np.isfinite(y).all():
        raise ValueError(f'{path}: se requiere WAV mono, 22050 Hz y 5 s; no se remuestrea')
    return y[:, 0]


def paths(args):
    return args.config, args.references


def signature(args):
    cfg, refs = paths(args)
    here = Path(__file__).resolve().parent
    files = [args.npz, cfg, refs, here/'mfcc_ligero.py', here/'modelo_npz_base.py', here/'etapa5.py', here/'rocket_native.py', here/'rocket_native.c', here/'librocket_native.so']
    return [digest(p) for p in files]


def validate(args):
    import numpy as np
    from mfcc_ligero import MFCCLigero
    cfg, refs = paths(args)
    stamp = args.trabajo/'validacion_ok.json'
    if stamp.exists(): stamp.unlink()
    extractor = MFCCLigero(cfg)
    from rocket_native import NativeApply
    base.compiled_transform = NativeApply
    model = base.NumericModel(args.npz)
    with np.load(refs, allow_pickle=False) as f:
        if str(f['model_hash']) != digest(args.npz): raise ValueError('Modelo distinto de la referencia')
        for name, y, expected, scores0, pred0, label0 in zip(
                f['names'], f['y'], f['X'], f['scores'], f['pred'], f['labels']):
            X = extractor(y)
            scores, pred, labels = model.predict(X)
            em = float(np.max(np.abs(X[0]-expected)))
            es = float(np.max(np.abs(scores[0]-scores0)))
            print(f'{name}: error MFCC={em:.8g}; error puntuaciones={es:.8g}', flush=True)
            # Umbrales fijos antes de observar los resultados de la Raspberry.
            np.testing.assert_allclose(X[0], expected, atol=1e-4, rtol=1e-5, equal_nan=False)
            np.testing.assert_allclose(scores[0], scores0, atol=1e-5, rtol=1e-5, equal_nan=False)
            np.testing.assert_array_equal(pred[0], pred0)
            np.testing.assert_array_equal(labels[0], label0)
    forbidden = set(sys.modules) & {'librosa','joblib','sklearn','sktime','pandas','detach_rocket','numba','llvmlite'}
    if forbidden: raise RuntimeError(f'Dependencias inesperadas: {sorted(forbidden)}')
    args.trabajo.mkdir(parents=True, exist_ok=True)
    stamp.write_text(json.dumps(signature(args)))
    print('VALIDACIÓN ETAPA 5: OK (12 entradas). Librosa, Numba y llvmlite no importados.')
    print('No usar la memoria de la validación como benchmark.')


def measure(args):
    # Ambos modos mantienen MFCC y parámetros; cambia la ejecución ROCKET.
    import numpy as np
    cfg, _ = paths(args)
    stamp = args.trabajo/'validacion_ok.json'
    if not stamp.exists() or json.loads(stamp.read_text()) != signature(args):
        raise RuntimeError('Falta validación vigente; ejecutar compilar.sh y validar')
    base.memory('inicio + numpy')
    t = time.perf_counter()
    from mfcc_ligero import MFCCLigero
    extractor = MFCCLigero(cfg)
    if args.motor == 'c':
        from rocket_native import NativeApply
        base.compiled_transform = NativeApply
    model = base.NumericModel(args.npz)
    load_time = time.perf_counter()-t
    base.memory('extractor + modelo')
    t = time.perf_counter()
    dummy = extractor(np.zeros(110250, dtype=np.float32))
    first_mfcc = time.perf_counter()-t
    base.memory('primer MFCC')
    t = time.perf_counter(); model.predict(dummy); warm = time.perf_counter()-t
    del dummy
    base.memory('primera predicción')
    t = time.perf_counter(); y = audio(args.wav); read_time = time.perf_counter()-t
    t = time.perf_counter(); X = extractor(y); mfcc_time = time.perf_counter()-t
    t = time.perf_counter(); scores, pred, labels = model.predict(X); pred_time = time.perf_counter()-t
    base.memory('audio real procesado')
    if args.motor == 'c' and set(sys.modules) & {'librosa','numba','llvmlite'}:
        raise RuntimeError('Dependencia excluida importada en modo C')
    print('Motor ROCKET:', args.motor)
    print('Sonido detectado:', labels[0])
    for label, value in [('Carga extractor y modelo',load_time),('Primer MFCC',first_mfcc),
                         ('Precarga numérica',warm),('Lectura WAV',read_time),('MFCC',mfcc_time),
                         ('Predicción incl. etiqueta',pred_time),('Procesamiento',mfcc_time+pred_time),
                         ('Total desde inicio Python',time.perf_counter()-START)]:
        print(f'{label}: {value:.4f} s')
    base.dependencies()
    print('MEDICIÓN ETAPA 5 COMPLETADA')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('modo', choices=['validar','medir'])
    p.add_argument('--npz', type=Path, default=Path('/home/rcaseres/modelo_detach_numerico_v1.npz'))
    p.add_argument('--audios', type=Path, default=Path('/home/rcaseres/audios_grabados'))
    p.add_argument('--trabajo', type=Path, default=Path('datos_etapa5'))
    p.add_argument('--wav', type=Path, default=Path('/home/rcaseres/audios_grabados/perfil_ciiy7sn6.wav'))
    p.add_argument('--motor', choices=['numba','c'], default='c')
    p.add_argument('--config', type=Path, default=Path('/home/rcaseres/etapa4_mfcc/datos_etapa4/mfcc_config.npz'))
    p.add_argument('--references', type=Path, default=Path('/home/rcaseres/etapa4_mfcc/datos_etapa4/referencias.npz'))
    a = p.parse_args()
    {'validar':validate,'medir':measure}[a.modo](a)

if __name__ == '__main__': main()
