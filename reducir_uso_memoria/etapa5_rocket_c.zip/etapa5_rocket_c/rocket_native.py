"""Interfaz NumPy/ctypes; sin Numba ni compilación durante la inferencia."""
import ctypes as ct
from pathlib import Path
import numpy as np

class NativeApply:
    def __init__(self):
        self.lib = ct.CDLL(str(Path(__file__).resolve().with_name('librocket_native.so')))
        fp = np.ctypeslib.ndpointer(dtype=np.float32, flags='C_CONTIGUOUS')
        ip = np.ctypeslib.ndpointer(dtype=np.int32, flags='C_CONTIGUOUS')
        self.fn = self.lib.rocket_apply
        self.fn.argtypes = [fp, ct.c_int64, ct.c_int64, ct.c_int64, fp, ip, fp, ip, ip, ip, ip, ct.c_int64, fp]
        self.fn.restype = ct.c_int

    def __call__(self, X, weights, lengths, biases, dilations, paddings, counts, indices):
        arrays = [X, weights, lengths, biases, dilations, paddings, counts, indices]
        dtypes = [np.float32,np.float32,np.int32,np.float32,np.int32,np.int32,np.int32,np.int32]
        for a, dtype in zip(arrays,dtypes):
            if not isinstance(a,np.ndarray) or a.dtype != np.dtype(dtype):
                raise ValueError(f'Tipo incompatible en llamada nativa: se requiere {dtype}')
        X,weights,lengths,biases,dilations,paddings,counts,indices = [np.ascontiguousarray(a) for a in arrays]
        if X.ndim != 3 or any(a.ndim != 1 for a in [weights,lengths,biases,dilations,paddings,counts,indices]):
            raise ValueError('Dimensiones incompatibles')
        nk=len(lengths)
        if nk==0 or any(len(a)!=nk for a in [biases,dilations,paddings,counts]): raise ValueError('Longitudes incompatibles')
        if not ((lengths>0).all() and (counts>0).all() and (dilations>0).all() and (paddings>=0).all()): raise ValueError('Kernels inválidos')
        if sum(int(l)*int(c) for l,c in zip(lengths,counts)) != weights.size or sum(map(int,counts)) != indices.size: raise ValueError('Offsets incompatibles')
        if not ((indices>=0)&(indices<X.shape[1])).all(): raise ValueError('Canal fuera de rango')
        if any(X.shape[2]+2*int(p)-(int(l)-1)*int(d)<=0 for l,d,p in zip(lengths,dilations,paddings)): raise ValueError('Serie demasiado corta')
        if not all(np.isfinite(a).all() for a in [X,weights,biases]): raise ValueError('Valores no finitos')
        out=np.empty((X.shape[0],2*nk),dtype=np.float32)
        status=self.fn(X,*X.shape,weights,lengths,biases,dilations,paddings,counts,indices,nk,out)
        if status: raise RuntimeError(f'Error nativo: {status}')
        if not np.isfinite(out).all(): raise ValueError('Resultado no finito')
        return out
