#include <stdint.h>
#include <math.h>
/* Arrays validados por Python; float32, muestras contiguas por canal.
   Mantiene PPV, máximo y el orden de suma de la implementación anterior. */
int rocket_apply(const float *x, int64_t batch, int64_t channels, int64_t time,
                 const float *weights, const int32_t *lengths,
                 const float *biases, const int32_t *dilations,
                 const int32_t *paddings, const int32_t *counts,
                 const int32_t *indices, int64_t nk, float *out) {
    for (int64_t b=0;b<batch;b++) {
        int64_t wp=0,cp=0;
        for (int64_t k=0;k<nk;k++) {
            int64_t length=lengths[k], count=counts[k], dilation=dilations[k], pad=paddings[k];
            int64_t end=time+pad-(length-1)*dilation;
            int64_t total=end+pad, positive=0;
            if (total<=0) return 1;
            float maximum=-INFINITY;
            for (int64_t start=-pad;start<end;start++) {
                float sum=biases[k];
                int64_t pos=start;
                for (int64_t j=0;j<length;j++,pos+=dilation) {
                    if (pos>=0 && pos<time) {
                        for (int64_t c=0;c<count;c++) {
                            float product=weights[wp+c*length+j]*x[(b*channels+indices[cp+c])*time+pos];
                            sum=sum+product;
                        }
                    }
                }
                if(sum>maximum) maximum=sum;
                if(sum>0) positive++;
            }
            out[b*2*nk+2*k]=(float)((double)positive/(double)total);
            out[b*2*nk+2*k+1]=maximum;
            wp+=count*length;cp+=count;
        }
    }
    return 0;
}
